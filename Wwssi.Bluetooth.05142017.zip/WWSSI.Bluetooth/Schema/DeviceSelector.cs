﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Wwssi.Bluetooth.Schema
{
    public enum DeviceSelector
    {
        BluetoothLe,
        BluetoothLePairedOnly,
        BluetoothLeUnpairedOnly
    }
}
